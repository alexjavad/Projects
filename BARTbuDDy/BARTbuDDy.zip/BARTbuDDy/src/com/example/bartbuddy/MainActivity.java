package com.example.bartbuddy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
	
	TextView selectOptionTextView;
	Button ticketingInfoButton;
	Button directMeButton;
	Button tripCostButton;
	Button nextTrainButton;
	Intent mIntent;
	HashMap<String, String> stationAbbrHashMap;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		selectOptionTextView = (TextView) findViewById(R.id.selectOptionTextView);
		ticketingInfoButton = (Button) findViewById(R.id.ticketingInfoButton);
		directMeButton = (Button) findViewById(R.id.directMeButton);
		tripCostButton = (Button) findViewById(R.id.tripCostButton);
		nextTrainButton = (Button) findViewById(R.id.nextTrainButton);
		stationAbbrHashMap = new HashMap<String, String>(52);
        
        stationAbbrHashMap.put("12th St. Oakland City Center", "12th");
        stationAbbrHashMap.put("16th St. Mission", "16th");
        stationAbbrHashMap.put("19th St. Oakland", "19th");
        stationAbbrHashMap.put("24th St. Mission", "24th");
        
        stationAbbrHashMap.put("Ashby", "ashb");
        stationAbbrHashMap.put("Balboa Park", "balb");
        stationAbbrHashMap.put("Bay Fair", "bayf");
        stationAbbrHashMap.put("Castro Valley", "cast");
        stationAbbrHashMap.put("Civic Center/UN Plaza", "civc");
        stationAbbrHashMap.put("UN Plaza", "civc"); 
        stationAbbrHashMap.put("Coliseum/Oakland Airport", "cols");        
        stationAbbrHashMap.put("Oakland Airport (OAK)", "cols");        
        stationAbbrHashMap.put("Colma", "colm");
        stationAbbrHashMap.put("Concord", "conc");
        stationAbbrHashMap.put("Daly City", "daly");
        stationAbbrHashMap.put("Downtown Berkeley", "dbrk");
        
        stationAbbrHashMap.put("Dublin/Pleasanton", "dubl");
        stationAbbrHashMap.put("Pleasanton", "dubl");
        stationAbbrHashMap.put("El Cerrito del Norte", "deln");
        stationAbbrHashMap.put("El Cerrito Plaza", "plza");
        stationAbbrHashMap.put("Embarcadero", "embr");
        stationAbbrHashMap.put("Fremont", "frmt");        
        stationAbbrHashMap.put("Fruitvale", "ftvl");
        stationAbbrHashMap.put("Glen Park", "glen");
        stationAbbrHashMap.put("Hayward", "hayw");
        stationAbbrHashMap.put("Lafayette", "lafy");
        stationAbbrHashMap.put("Lake Merritt", "lake");
        
        stationAbbrHashMap.put("MacArthur", "mcar");
        stationAbbrHashMap.put("Millbrae", "mlbr");
        stationAbbrHashMap.put("Montgomery St.", "mont");
        stationAbbrHashMap.put("North Berkeley", "nbrk");
        stationAbbrHashMap.put("North Concord/Martinez", "ncon");
        stationAbbrHashMap.put("Martinez", "ncon");
        stationAbbrHashMap.put("Orinda", "orin");
        stationAbbrHashMap.put("Pittsburg/Bay Point", "pitt");
        stationAbbrHashMap.put("Bay Point", "pitt");
        stationAbbrHashMap.put("Pleasant Hill/Contra Costa Centre", "phil");
        stationAbbrHashMap.put("Contra Costa Centre", "phil");
        stationAbbrHashMap.put("Powell St.", "powl");
        stationAbbrHashMap.put("Richmond", "rich");
        
        stationAbbrHashMap.put("Rockridge", "rock");
        stationAbbrHashMap.put("San Bruno", "sbrn");
        stationAbbrHashMap.put("San Francisco Int'l Airport (SFO)", "sfia");
        stationAbbrHashMap.put("SFO (San Francisco Int\'l Airport)", "sfia");
        stationAbbrHashMap.put("San Leandro", "sanl");
        stationAbbrHashMap.put("South Hayward", "shay");        
        stationAbbrHashMap.put("South San Francisco", "ssan");
        stationAbbrHashMap.put("Union City", "ucty");
        stationAbbrHashMap.put("Walnut Creek", "wcrk");
        stationAbbrHashMap.put("West Dublin/Pleasanton", "wdub");
        stationAbbrHashMap.put("West Pleasanton", "wdub");
        stationAbbrHashMap.put("West Oakland", "woak");
        	
	}
	
    public void ticketingInfoOnClick(View v) {
    	if(v.getId() == R.id.ticketingInfoButton) {
    		getTicketingInfo();
    	}
    }
    
    public void getTicketingInfo() {
    	mIntent = new Intent(MainActivity.this, TicketingActivity.class);
   		startActivity(mIntent);    	
    }
    
    
    public void directMeOnClick(View v) {
    	if(v.getId() == R.id.directMeButton) {
    		getDirectionInfo();
    	}
    }
    
    public void getDirectionInfo() {
    	mIntent = new Intent(MainActivity.this, DirectMeActivity.class);
   		startActivity(mIntent);	
    }
    
    public void tripCostOnClick(View v) {
    	if(v.getId() == R.id.tripCostButton) {
    		getTripCost();
    	}
    }
    
    public void getTripCost() {
    	mIntent = new Intent(MainActivity.this, TripCostActivity.class);
    	mIntent.putExtra("stationAbbrHashMap", stationAbbrHashMap);
   		startActivity(mIntent);
    }
    
    public void nextTrainOnClick(View v) {
    	if(v.getId() == R.id.nextTrainButton) {
    		getNextTrainInfo();
    	}
    }
    
    public void getNextTrainInfo() {
    	mIntent = new Intent(MainActivity.this, NextTrainActivity.class);
    	mIntent.putExtra("stationAbbrHashMap", stationAbbrHashMap);
   		startActivity(mIntent);
    }

}
