package com.example.bartbuddy;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class TripCostActivity extends Activity {

	TextView calculateTripCostTextView;
	TextView startingStationTextView;
	AutoCompleteTextView startingStationValue;
	AutoCompleteTextView endStationValue;
	TextView endStationTextView;
	Button calcFareButton;
	TextView oneWayFareTextView;
	TextView oneWayFareValueTextView;
	TextView roundTripFareTextView;
	TextView roundTripFareValueTextView;
	Intent mIntent;
	Bundle myBundle;
	CalcFareTask mCalcFareTask;
	HashMap<String, String> stationAbbrHashMap;
	RelativeLayout tripCostLayout;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tripcost);
		calculateTripCostTextView = (TextView) findViewById(R.id.calculateTripCostTextView);
		startingStationTextView = (TextView) findViewById(R.id.startingStationTextView);
		startingStationValue = (AutoCompleteTextView) findViewById(R.id.startingStationValue);
		endStationValue = (AutoCompleteTextView) findViewById(R.id.endStationValue);
		String[] stations = getResources().getStringArray(R.array.stations_array);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stations);
		startingStationValue.setAdapter(adapter);
		endStationValue.setAdapter(adapter);
		endStationTextView = (TextView) findViewById(R.id.endStationTextView);
		calcFareButton = (Button) findViewById(R.id.calcFareButton);
		oneWayFareTextView = (TextView) findViewById(R.id.oneWayFareTextView);
		oneWayFareValueTextView = (TextView) findViewById(R.id.oneWayFareValueTextView);
		roundTripFareTextView = (TextView) findViewById(R.id.roundTripFareTextView);
		roundTripFareValueTextView = (TextView) findViewById(R.id.roundTripFareValueTextView);
		mIntent = getIntent();
		myBundle = mIntent.getExtras();
		stationAbbrHashMap = (HashMap<String, String>) myBundle.get("stationAbbrHashMap");		
	}

	public void calcFareOnClick(View v) {
		if(v.getId() == R.id.calcFareButton) {
			String startStation = startingStationValue.getText().toString();
			String endStation = endStationValue.getText().toString();
			try {
				if(startStation.equals(endStation)) {
					throw new IllegalArgumentException();
				} else {
					calculateFare();
				}
			} catch (IllegalArgumentException e){
				oneWayFareValueTextView.setText("(First Enter Station Info. then Tap 'Calculate Fare')");
				roundTripFareValueTextView.setText("(First Enter Station Info. then Tap 'Calculate Fare')");
				AlertDialog.Builder dialog = new AlertDialog.Builder(this);
	            dialog.setTitle("IllegalArgument Error: Start Station Cannot Equal End Station! Try Again.");
	            dialog.setMessage(e.getMessage());
	            dialog.setNeutralButton("OK", null);
	            dialog.create().show();
			}
		}
	}

	public void calculateFare() {
		String startStation = startingStationValue.getText().toString();
		String endStation = endStationValue.getText().toString();


		String startAbbr = stationAbbrHashMap.get(startStation);
		String endAbbr = stationAbbrHashMap.get(endStation);

		String[] urlParams = {"sched", "fare", startAbbr, endAbbr};
		mCalcFareTask = new CalcFareTask();
		mCalcFareTask.execute(urlParams);
	}

	private class CalcFareTask extends AsyncTask<String, Void, String> {

		private Document xmlDocument;

		public String doInBackground(String... urlParams)
		{
			if (urlParams != null) {
				final String API_KEY = "MW9S-E7SL-26DU-VV8V";
				String urlParam1 = urlParams[0];
				String urlParam2 = urlParams[1];
				String urlParam3 = urlParams[2];
				String urlParam4 = urlParams[3];

				String url = "http://api.bart.gov/api/" + urlParam1 + ".aspx?cmd=" + urlParam2 + "&orig=" + urlParam3 + "&dest=" + urlParam4 + "&key=" + API_KEY;
				HttpClient httpclient = new DefaultHttpClient();
				HttpResponse response;
				String responseString = null;


				try {
					response = httpclient.execute(new HttpGet(url));
					StatusLine statusLine = response.getStatusLine();
					if(statusLine.getStatusCode() == HttpStatus.SC_OK){
						ByteArrayOutputStream out = new ByteArrayOutputStream();
						response.getEntity().writeTo(out);
						out.close();
						responseString = out.toString();
					} else{
						//Closes the connection.
						response.getEntity().getContent().close();
						throw new IOException(statusLine.getReasonPhrase());
					}
				} catch (ClientProtocolException e) {
					//TODO Handle problems..
				} catch (IOException e) {
					//TODO Handle problems..
				}
				return responseString;
			}
			else {       
				throw new IllegalArgumentException("Must provide terms");
			}
		}

		@Override
		protected void onPostExecute(String results)
		{       
			if(results != null)
			{   
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					InputSource is = new InputSource(new StringReader(results));
					xmlDocument = builder.parse(is);
					if (xmlDocument != null) {
						String tripFare = "";
						NodeList tripFareNodeList = xmlDocument.getElementsByTagName("fare");
						tripFare = tripFareNodeList.item(0).getTextContent();
						oneWayFareValueTextView.setText("$" + tripFare);
						Float myFloat = new Float(tripFare);						
						if(tripFare.endsWith("0") || tripFare.endsWith("5")) {
							String roundTripValString = String.valueOf(myFloat.floatValue()*2);
							roundTripFareValueTextView.setText("$" + roundTripValString + "0");
						} else {
							String roundTripValString = String.valueOf(myFloat.floatValue()*2);
							roundTripFareValueTextView.setText("$" + roundTripValString);
						}

					}					
				}           	
				catch (Exception ex) {
					//do something
				}
			}
		}
	}

}
