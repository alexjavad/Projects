package com.example.bartbuddy;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class NextTrainActivity extends Activity implements LocationListener {

	LocationManager manager;
	TextView nextTrainTextView;
	TextView closestStationValue;
	TextView textView2;
	TextView depTimeResults;
	Intent mIntent;
	Bundle myBundle;
	HashMap<String, String> stationAbbrHashMap;
	HashMap<String, Coordinate> stationCoordHashMap;
	HashMap<Float, Coordinate> distanceCoordHashMap;
	double myCurrLat;
	double myCurrLong;
	NextTrainTask mNextTrainTask;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_nexttrain);
		nextTrainTextView = (TextView) findViewById(R.id.nextTrainTextView);
		closestStationValue = (TextView) findViewById(R.id.closestStationValue);
		depTimeResults = (TextView) findViewById(R.id.depTimeResults);
		textView2 = (TextView) findViewById(R.id.textView2);
		mIntent = getIntent();
		myBundle = mIntent.getExtras();
		stationAbbrHashMap = (HashMap<String, String>) myBundle.get("stationAbbrHashMap"); 
		stationCoordHashMap = new HashMap<String, Coordinate>(52);
		distanceCoordHashMap = new HashMap<Float, Coordinate>(60);

		stationCoordHashMap.put("12th St. Oakland City Center", new Coordinate(37.803664, -122.271604));
		stationCoordHashMap.put("16th St. Mission", new Coordinate(37.765062, -122.419694));
		stationCoordHashMap.put("19th St. Oakland", new Coordinate(37.80787, -122.269029));
		stationCoordHashMap.put("24th St. Mission", new Coordinate(37.752254, -122.418466));

		stationCoordHashMap.put("Ashby", new Coordinate(37.853024, -122.26978));
		stationCoordHashMap.put("Balboa Park", new Coordinate(37.72198087, -122.4474142));
		stationCoordHashMap.put("Bay Fair", new Coordinate(37.697185, -122.126871));
		stationCoordHashMap.put("Castro Valley", new Coordinate(37.690754, -122.075567));
		stationCoordHashMap.put("Civic Center/UN Plaza", new Coordinate(37.779528, -122.413756));        
		stationCoordHashMap.put("Coliseum/Oakland Airport", new Coordinate(37.754006, -122.197273));               
		stationCoordHashMap.put("Colma", new Coordinate(37.684638, -122.466233));
		stationCoordHashMap.put("Concord", new Coordinate(37.973737, -122.029095));
		stationCoordHashMap.put("Daly City", new Coordinate(37.70612055, -122.4690807));
		stationCoordHashMap.put("Downtown Berkeley", new Coordinate(37.869867, -122.268045));

		stationCoordHashMap.put("Dublin/Pleasanton", new Coordinate(37.701695, -121.900367));
		stationCoordHashMap.put("El Cerrito del Norte", new Coordinate(37.925655, -122.317269));
		stationCoordHashMap.put("El Cerrito Plaza", new Coordinate(37.9030588, -122.2992715));
		stationCoordHashMap.put("Embarcadero", new Coordinate(37.792976, -122.396742));
		stationCoordHashMap.put("Fremont", new Coordinate(37.557355, -121.9764));        
		stationCoordHashMap.put("Fruitvale", new Coordinate(37.774963, -122.224274));
		stationCoordHashMap.put("Glen Park", new Coordinate(37.732921, -122.434092));
		stationCoordHashMap.put("Hayward", new Coordinate(37.670399, -122.087967));
		stationCoordHashMap.put("Lafayette", new Coordinate(37.893394, -122.123801));
		stationCoordHashMap.put("Lake Merritt", new Coordinate(37.797484, -122.265609));

		stationCoordHashMap.put("MacArthur", new Coordinate(37.828415, -122.267227));
		stationCoordHashMap.put("Millbrae", new Coordinate(37.599787, -122.38666));
		stationCoordHashMap.put("Montgomery St.", new Coordinate(37.789256, -122.401407));
		stationCoordHashMap.put("North Berkeley", new Coordinate(37.87404, -122.283451));
		stationCoordHashMap.put("North Concord/Martinez", new Coordinate(38.003275, -122.024597));
		stationCoordHashMap.put("Orinda", new Coordinate(37.87836087, -122.1837911));
		stationCoordHashMap.put("Pittsburg/Bay Point", new Coordinate(38.018914, -121.945154));
		stationCoordHashMap.put("Pleasant Hill/Contra Costa Centre", new Coordinate(37.928403, -122.056013));
		stationCoordHashMap.put("Powell St.", new Coordinate(37.784991, -122.406857));
		stationCoordHashMap.put("Richmond", new Coordinate(37.936887, -122.353165));

		stationCoordHashMap.put("Rockridge", new Coordinate(37.844601, -122.251793));
		stationCoordHashMap.put("San Bruno", new Coordinate(37.637753, -122.416038));
		stationCoordHashMap.put("San Francisco Int'l Airport (SFO)", new Coordinate(37.616035, -122.392612));
		stationCoordHashMap.put("San Leandro", new Coordinate(37.72261921, -122.1613112));
		stationCoordHashMap.put("South Hayward", new Coordinate(37.63479954, -122.0575506));        
		stationCoordHashMap.put("South San Francisco", new Coordinate(37.664174, -122.444116));
		stationCoordHashMap.put("Union City", new Coordinate(37.591208, -122.017867));
		stationCoordHashMap.put("Walnut Creek", new Coordinate(37.905628, -122.067423));
		stationCoordHashMap.put("West Dublin/Pleasanton", new Coordinate(37.699759, -121.928099));
		stationCoordHashMap.put("West Oakland", new Coordinate(37.80467476, -122.2945822));              

		manager =  (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
			Toast.makeText(this, "GPS is disabled.", Toast.LENGTH_SHORT).show();
		} else {
			//get a location provider from location manager
			//empty criteria searches through all providers and returns the best one
			String providerName = manager.getBestProvider(new Criteria(), true);
			Location location = manager.getLastKnownLocation(providerName);	
			myCurrLat = location.getLatitude();
			myCurrLong = location.getLongitude();
			//sign up to be notified of location updates every 15 seconds - for production code this should be at least a minute
			manager.requestLocationUpdates(providerName, 15000, 1, this);
		}

		Coordinate closestStationCoord = closestStationCoord();
		String closestStationName = getKey(stationCoordHashMap, closestStationCoord);
		String closestStationAbbr = stationAbbrHashMap.get(closestStationName);

		closestStationValue.setText(closestStationName);

		String[] urlParams = {"etd", "etd", closestStationAbbr};
        mNextTrainTask = new NextTrainTask();
		mNextTrainTask.execute(urlParams);

	}
	
	private class NextTrainTask extends AsyncTask<String, Void, String> {

		private Document xmlDocument;

		public String doInBackground(String... urlParams)
		{
			if (urlParams != null) {
				final String API_KEY = "MW9S-E7SL-26DU-VV8V";
				String urlParam1 = urlParams[0];
				String urlParam2 = urlParams[1];
				String urlParam3 = urlParams[2];

				String url = "http://api.bart.gov/api/" + urlParam1 + ".aspx?cmd=" + urlParam2 + "&orig=" + urlParam3 + "&key=" + API_KEY;
				HttpClient httpclient = new DefaultHttpClient();
				HttpResponse response;
				String responseString = null;


				try {
					response = httpclient.execute(new HttpGet(url));
					StatusLine statusLine = response.getStatusLine();
					if(statusLine.getStatusCode() == HttpStatus.SC_OK){
						ByteArrayOutputStream out = new ByteArrayOutputStream();
						response.getEntity().writeTo(out);
						out.close();
						responseString = out.toString();
					} else{
						//Closes the connection.
						response.getEntity().getContent().close();
						throw new IOException(statusLine.getReasonPhrase());
					}
				} catch (ClientProtocolException e) {
					//TODO Handle problems..
				} catch (IOException e) {
					//TODO Handle problems..
				}
				return responseString;
			}
			else {       
				throw new IllegalArgumentException("Must provide terms");
			}
		}

		@Override
		protected void onPostExecute(String results)
		{       
			if(results != null)
			{   
				try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					InputSource is = new InputSource(new StringReader(results));
					xmlDocument = builder.parse(is);
					if (xmlDocument != null) {
						NodeList destinations = xmlDocument.getElementsByTagName("etd");								
						String destDepartureInfo = "";
						boolean firstDest = true;
						
						for(int i = 0; i < destinations.getLength(); i++){
							Element dest = (Element) destinations.item(i);
							String destination = dest.getElementsByTagName("destination").item(0).getTextContent();
							destDepartureInfo += destination + ": ";
							
							NodeList etdNodeList = dest.getElementsByTagName("estimate");
							for(int j = 0; j < etdNodeList.getLength(); j++){
								Element curr_etd = (Element) etdNodeList.item(j);
								NodeList depTimeNodeList = curr_etd.getElementsByTagName("minutes");
								for(int k = 0; k < depTimeNodeList.getLength(); k++){
									String leavingInMinutes = depTimeNodeList.item(k).getTextContent();
									if(firstDest){
										destDepartureInfo += leavingInMinutes + "mins";
										firstDest = false;
									}else
										destDepartureInfo += ", " + leavingInMinutes + "mins";
									}
								}
							
							destDepartureInfo += "\n";
							firstDest = true;
						}
						
						
						depTimeResults.setText(destDepartureInfo);
					}					
				}           	
				catch (Exception ex) {
					//do something
				}
			}
		}
	}


	@Override
	public void onLocationChanged(Location location) {
		if (location != null) {
			myCurrLat = location.getLatitude();
			myCurrLong = location.getLongitude();
		}
	}

	@Override
	public void onProviderDisabled(String arg0) {}

	@Override
	public void onProviderEnabled(String arg0) {}

	@Override
	public void onStatusChanged(String arg0, int arg1, Bundle arg2) {}

	private String getKey(HashMap<String, Coordinate> map, Coordinate coord){
		String result = "";
		Entry<String, Coordinate> currMapping;
		Set<Entry<String, Coordinate>> setOfMappings = map.entrySet();
		Iterator<Entry<String, Coordinate>> mappingIterator = setOfMappings.iterator();
		while(mappingIterator.hasNext()) {
			currMapping = mappingIterator.next();
			String currKey = currMapping.getKey();
			Coordinate currVal = currMapping.getValue();
			if(coord.equals(currVal)) {
				result = currKey;
			}
		}
		return result;
	}

	private Coordinate closestStationCoord() {
		Coordinate currCoord = null;
		double currLat;
		double currLong;
		float currDist;
		Collection<Coordinate> coordCollection = stationCoordHashMap.values();
		Iterator<Coordinate> coordIterator = coordCollection.iterator();
		while(coordIterator.hasNext()) {
			currCoord = coordIterator.next();
			currLat = currCoord.getLatitude();
			currLong = currCoord.getLongitude();
			float[] currDistArray = new float[1];
			Location.distanceBetween(myCurrLat, myCurrLong, currLat, currLong, currDistArray);
			currDist = currDistArray[0];
			distanceCoordHashMap.put(currDist, currCoord); 
		}
		
		
		Entry<Float, Coordinate> currMapping;
		Set<Entry<Float, Coordinate>> setOfMappings = distanceCoordHashMap.entrySet();
		Iterator<Entry<Float, Coordinate>> mappingIterator = setOfMappings.iterator();
		Float minDist = mappingIterator.next().getKey();
		while(mappingIterator.hasNext()) {
			currMapping = mappingIterator.next();
			Float thisDist = currMapping.getKey();
			Coordinate thisCoord = currMapping.getValue();
			minDist = Math.min(minDist, thisDist);
		}
		return distanceCoordHashMap.get(minDist);
	}

}
