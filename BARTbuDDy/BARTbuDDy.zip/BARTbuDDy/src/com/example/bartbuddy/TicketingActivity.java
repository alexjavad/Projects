package com.example.bartbuddy;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TicketingActivity extends Activity {
	
	Intent mIntent;
	Bundle myBundle;
	Button step2Button;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ticketing);
		step2Button = (Button) findViewById(R.id.step2Button);
	}
	
    public void step2onClick(View v) {
    	if(v.getId() == R.id.step2Button) {
    		getStep2();
    	}
    }
    
    public void getStep2() {
    	mIntent = new Intent(TicketingActivity.this, TicketingActivity2.class);
   		startActivity(mIntent);    	
    }
	

}
