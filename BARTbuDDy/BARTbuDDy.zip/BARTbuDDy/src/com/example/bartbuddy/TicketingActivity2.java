package com.example.bartbuddy;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class TicketingActivity2 extends Activity {
	
	ImageView imageView1;
	Button step3Button;
	Intent mIntent;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ticketing2);
		step3Button = (Button) findViewById(R.id.step3Button);
	}
	
	
    public void step3onClick(View v) {
    	if(v.getId() == R.id.step3Button) {
    		getStep3();
    	}
    }
    
    public void getStep3() {
    	mIntent = new Intent(TicketingActivity2.this, TicketingActivity3.class);
   		startActivity(mIntent);    	
    }

}
